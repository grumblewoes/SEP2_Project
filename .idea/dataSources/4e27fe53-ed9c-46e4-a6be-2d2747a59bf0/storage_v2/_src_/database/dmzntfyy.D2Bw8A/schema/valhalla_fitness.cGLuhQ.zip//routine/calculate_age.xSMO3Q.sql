create function calculate_age() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.age := DATE_PART('year', AGE(NEW.date_of_birth));
    RETURN NEW;
END;
$$;

alter function calculate_age() owner to dmzntfyy;

