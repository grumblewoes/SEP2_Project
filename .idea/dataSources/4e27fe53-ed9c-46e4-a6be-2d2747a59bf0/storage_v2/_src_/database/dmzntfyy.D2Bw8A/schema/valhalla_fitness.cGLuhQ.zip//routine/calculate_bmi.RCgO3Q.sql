create function calculate_bmi() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.bmi := ROUND(NEW.weight / (NEW.height / 100.0 * NEW.height / 100.0), 2);
  RETURN NEW;
END;
$$;

alter function calculate_bmi() owner to dmzntfyy;

