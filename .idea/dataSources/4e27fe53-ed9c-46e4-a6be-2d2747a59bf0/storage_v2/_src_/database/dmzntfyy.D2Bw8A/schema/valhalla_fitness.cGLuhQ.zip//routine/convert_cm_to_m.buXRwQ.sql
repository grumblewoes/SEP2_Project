create function convert_cm_to_m(height numeric) returns numeric
    language plpgsql
as
$$
BEGIN
  RETURN height/100.0;
END;
    $$;

alter function convert_cm_to_m(numeric) owner to dmzntfyy;

